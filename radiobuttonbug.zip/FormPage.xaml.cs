﻿using CommunityToolkit.Maui.Views;

namespace MauiApp1;

public partial class FormPage : Popup
{
	public FormPage()
	{
		InitializeComponent();
	}

}